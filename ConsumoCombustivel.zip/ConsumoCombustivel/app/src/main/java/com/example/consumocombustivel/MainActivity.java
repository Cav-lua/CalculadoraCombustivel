package com.example.consumocombustivel;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editnomeveiculo, editnumeroplaca, editdistancia, editconsumomedio, editprecolitro;
    private TextView textresultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editnomeveiculo = findViewById(R.id.editnomeveiculo);
        editnumeroplaca = findViewById(R.id.editnumeroplaca);
        editdistancia = findViewById(R.id.editdistancia);
        editconsumomedio = findViewById(R.id.editconsumomedio);
        editprecolitro = findViewById(R.id.editprecolitro);
        textresultado = findViewById(R.id.textresultado);
        Button btncalcular = findViewById(R.id.btncalcular);

        btncalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularConsumo();
            }
        });
    }

    private void calcularConsumo() {
        try {
            double distancia = Double.parseDouble(editdistancia.getText().toString());
            double consumomedio = Double.parseDouble(editconsumomedio.getText().toString());
            double precolitro = Double.parseDouble(editprecolitro.getText().toString());

            double combustivelnecessario = distancia / consumomedio;
            double custoviagem = combustivelnecessario * precolitro;


            String resultado = String.format("Combustível necessário: %.2f litros\nCusto da viagem: R$ %.2f", combustivelnecessario, custoviagem);
            textresultado.setText(resultado);

        } catch (NumberFormatException e) {
            textresultado.setText("Por favor, preencha todos os campos corretamente.");
        }
    }
}